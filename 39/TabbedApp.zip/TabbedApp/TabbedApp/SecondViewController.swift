//
//  SecondViewController.swift
//  TabbedApp
//
//  Created by Martin Lexow on 2018-04-21.
//  Copyright © 2018 IXEAU. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

