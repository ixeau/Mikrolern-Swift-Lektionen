


import UIKit


class MeinViewController: UIViewController {

    
    var meinArrayIndex: Int? // Empfangen wir über den 'Seque' des 'MeinTableViewController'
    @IBOutlet weak var meinLabel: UILabel!

    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        if let index = meinArrayIndex {
            self.navigationItem.title = String(index)
            meinLabel.text = vornamen[index]
        }

    }


}

