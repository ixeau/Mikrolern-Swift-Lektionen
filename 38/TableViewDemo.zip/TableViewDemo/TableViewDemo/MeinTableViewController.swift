


import UIKit



var vornamen = ["Martin", "Jannis", "Markus"]



class MeinTableViewController: UITableViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // Anzahl an 'Sections'
        return 1
    }

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Anzahl an 'Zeilen'
        return vornamen.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "meineZelle", for: indexPath)
        // Den identifier 'meineZelle' haben wir im Interface Builder zugewiesen.
        
        cell.textLabel?.text = vornamen[indexPath.row]
        // Über 'indexPath.row' erhalten wir die jeweilige Nummer der Zeile.
        
        return cell
        
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        /*
         Ein 'Segue' ist ein Übergang zur nächsten Ansicht / ViewController.
         Um Daten an den entsprechenden ViewController zu übermitteln,
         müssen wir zunächst sicherstellen, um welchen es sich handelt:
         */
        
        if let destinationVC = segue.destination as? MeinViewController {
            
            destinationVC.meinArrayIndex = tableView.indexPathForSelectedRow?.row
            
        }
        
    }
 

}

