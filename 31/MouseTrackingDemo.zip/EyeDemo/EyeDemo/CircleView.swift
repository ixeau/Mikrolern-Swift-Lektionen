


import Cocoa



@IBDesignable public class CircleView: NSView {
    
    
    @IBInspectable public var backgroundColor: NSColor = NSColor.white // Hintergrundfarbe
    @IBInspectable public var strokeColor: NSColor = NSColor.black // Linienfarbe
    @IBInspectable public var strokeWidth: CGFloat = 4.0 // Linienstärke
    
    
    override public func draw(_ dirtyRect: NSRect) {
        
        super.draw(dirtyRect)

        // Kreis zeichnen
        let circleRect = NSRect(x: strokeWidth,
                                y: strokeWidth,
                                width: self.bounds.width - strokeWidth * 2,
                                height: self.bounds.height - strokeWidth * 2)
    
        let circle = NSBezierPath(ovalIn: circleRect)
        
        /* ⇡ ⇡ ⇡
         Wir könnten theoretisch auch 'self.bounds' oder 'dirtyRect' statt 'circleRect' verwenden.
         Der Kreis allein würde darin korrekt dargestellt werden.
         Die Liniestärke als Kontur des Kreises wird jedoch auf diesen drauf addiert.
         Daher haben wir mit 'circleRect' ein eigenes Rectangle definiert, dass je nach
         Linienstärke den Bereich für den Kreis selbst entsprechend verkleinert.
         */
        
        
        // Hintergrund
        self.backgroundColor.setFill()
        circle.fill()
        
        // Linie
        self.strokeColor.setStroke()
        circle.lineWidth = strokeWidth
        circle.stroke()
        
    }
    
    
}



