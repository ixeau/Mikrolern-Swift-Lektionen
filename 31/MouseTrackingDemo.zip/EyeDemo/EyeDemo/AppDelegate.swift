


import Cocoa


@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    // Hier gibt es (fast) nichts zu sehen 👀
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        // Hiermit wird die App beendet, sobald das Fenster geschlossen wird
        return true
    }

}



