


import Cocoa



class ViewController: NSViewController {

    
    // Outlets des Interface Builder
    @IBOutlet var eyeLeft: EyeView!
    @IBOutlet var eyeRight: EyeView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Maus-Events überwachen
        NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved]) { _ in
            self.eyeLeft.needsDisplay = true
            self.eyeRight.needsDisplay = true
        }
        
        NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved]) {
            self.eyeLeft.needsDisplay = true
            self.eyeRight.needsDisplay = true
            return $0
        }
        
    }
    
    override func viewWillAppear() {
        
        // Hintergrundfarbe vergeben
        self.view.wantsLayer = true
        self.view.layer?.backgroundColor = NSColor.yellow.cgColor
        
    }



}




