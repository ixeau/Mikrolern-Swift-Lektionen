


import Cocoa



@IBDesignable public class EyeView: NSView {
    
    
    override public func draw(_ dirtyRect: NSRect) {
        
        super.draw(dirtyRect)
        
        /*
         Manchmal ist Code zu aufwendig, um in Echtzeit berechnet zu werden.
         Mit 'DispatchQueue' können wir den Code asynchron ausführen:
         ⇣ ⇣ ⇣
         */
        DispatchQueue.main.async {
        
            /*
             Erstmal Aufräumen! Zunächst entfernen wir alle möglicherweise bereits vorhandenen
             Subviews aus unserem 'EyeView'. Wir fügen im späteren Verlauf unseres
             Codes selbst neue Subviews hinzu, es könnten also welche vorhanden sein.
             Die Funktion in der wir uns hier befinden (namens 'draw') wird z.B. immer
             dann ausgeführt, wenn wir im ViewController 'needsDisplay' setzen.
             ⇣ ⇣ ⇣
             */
            self.subviews.removeAll()
            
            
            // Auge
            let eye = CircleView(frame: self.bounds)
            self.addSubview(eye)
            
            
            // Pupille
            /*
             Die Pupille soll nur halb so groß sein wie das Auge selbst, daher teilen
             wir die 'width' und 'height' von 'eye' einfach durch 2. Die horizontale Position
             wird durch 'x' bestimmt, die vertikale durch 'y'. Die Division durch vier bewirkt,
             dass die Pupille genau in der Mitte steht.
             ⇣ ⇣ ⇣
             */
            let pupilFrame = NSRect(x: eye.frame.width / 4,
                                    y: eye.frame.height / 4,
                                    width: eye.frame.width / 2,
                                    height: eye.frame.height / 2)
            let pupil = CircleView(frame: pupilFrame)
            pupil.backgroundColor = NSColor.black
            self.addSubview(pupil)
            
            
            // Augen-Ansicht
            /*
             Die 'mouseLocation' (siehe unten) gibt uns ihre absolute Position auf dem Bildschirm zurück.
             Eine solche absolute Position benötigen wir auch für unser Auge, damit wir abhängig davon
             die Position der Pupille ausrechnen können. Mit 'convertToScreen' können wir die Koordinaten
             des EyeView ('self.frame') entsprechend umrechnen.
             ⇣ ⇣ ⇣
             */
            let eyeViewLocationOnScreen = self.window!.convertToScreen(self.frame)
            print("\nEyeView:\t\t\(eyeViewLocationOnScreen)")
            
            
            // Maus Position
            let mouseLocation = NSEvent.mouseLocation
            print("mouseLocation:\t\(mouseLocation)")

            
            // Vertikale Position (Y)
            let minY = eyeViewLocationOnScreen.origin.y + pupil.frame.height / 2
            let maxY = (eyeViewLocationOnScreen.origin.y + self.frame.height) - pupil.frame.height / 2
            /* ⇡ ⇡ ⇡
             Die Pupille soll nicht über das Auge hinaus wandern! Daher berechnen wir sowohl den
             minimalen als auch den maximalen Y-Wert, der die vertikale Position bestimmt.
             */
            
            var posY: CGFloat = pupil.frame.origin.y

            if mouseLocation.y <= minY {
                // Die Maus befindet sich unter dem 'EyeView'
                print("Unten")
                posY = 0.0 // Pupille ist am unteren Rand des Auges
            }

            if mouseLocation.y >= maxY {
                // Die Maus befindet sich über dem 'EyeView'
                print("Oben")
                posY = eye.frame.height - pupil.frame.height // Pupille ist am oberen Rand des Auges
            }
            
            if mouseLocation.y > minY && mouseLocation.y < maxY {
                // Die Maus befindet sich innerhalb des 'EyeView'
                posY = maxY / minY * mouseLocation.y - maxY // Die Mitte der Pupille ist auf Höhe der Maus
            }
            
            
            // Horizontale Position (X)
            let minX = eyeViewLocationOnScreen.origin.x + pupil.frame.width / 2
            let maxX = (eyeViewLocationOnScreen.origin.x + self.frame.width) - pupil.frame.width / 2
            
            var posX: CGFloat = pupil.frame.origin.x
            
            if mouseLocation.x <= minX {
                print("Links") // Die Maus befindet sich links vom 'EyeView'
                posX = 0.0 // Pupille ist am linken Rand des Auges
            }
            
            if mouseLocation.x >= maxX {
                print("Rechts") // Die Maus befindet sich rechts vom 'EyeView'
                posX = eye.frame.width - pupil.frame.width // Pupille ist am rechten Rand des Auges
            }
            
            if mouseLocation.x > minX && mouseLocation.x < maxX {
                // Die Maus befindet sich innerhalb des 'EyeView'
                posX = maxX / minX * mouseLocation.x - maxX // Die Mitte der Pupille ist auf Breite der Maus
            }
            
            
            // Finalisieren
            let pupilLocation = NSPoint(x: posX, y: posY) // Berechnete Positionen zusammenführen
            pupil.setFrameOrigin(pupilLocation) // Position an die Pupille übergeben

            
        }
        
    }
    
    
}

