


import Cocoa



class ViewController: NSViewController {
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        /*
         HINTERGRUNDBILD
         Wir laden das Foto des Pixelrasens als 'NSImage'.
         Mithilfe von 'NSColor' machen wir aus unserem image
         dann ein Objekt vom Typen 'NSColor' (also einer Farbe).
         Diese Farbe können wir dem 'Layer' als Hintergrundfarbe
         zuweisen.
         */
        let image = NSImage(named: NSImage.Name(rawValue: "pixelrasen"))!
        let color = NSColor(patternImage: image).cgColor
        
        self.view.wantsLayer = true
        self.view.layer?.backgroundColor = color

    }


}



