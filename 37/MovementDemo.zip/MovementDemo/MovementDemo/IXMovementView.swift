


import Cocoa



class IXMovementView: NSView {

    
    override var acceptsFirstResponder: Bool {
        return true
    }
    
    
    override func draw(_ dirtyRect: NSRect) {
        
        super.draw(dirtyRect)

        /*
         GEIST
         Wir laden das Foto des Geistes als 'NSImage'.
         Mithilfe von 'NSColor' machen wir aus unserem image
         dann ein Objekt vom Typen 'NSColor' (also einer Farbe).
         Diese Farbe können wir dem 'Layer' als Hintergrundfarbe
         zuweisen.
         */
        let image = NSImage(named: NSImage.Name(rawValue: "geist"))!
        let color = NSColor(patternImage: image).cgColor
        
        self.wantsLayer = true
        self.layer?.backgroundColor = color
        
        self.becomeFirstResponder()
        
    }
    
    
    
    override func keyDown(with event: NSEvent) {
        
        /*
         Diese Funktion wird ausgeführt, wenn eine
         Taste auf deiner Tastatur gedrückt worden ist.
         */
        
        
        // Jede Taste hat einen anderen 'keyCode'
        print("Taste gedrückt: \(event.keyCode)")

        
        /*
         Die Schrittlänge gibt an, wie weit unser
         Geist laufen soll, wenn wir eine Taste drücken.
         */
        let schrittLänge: CGFloat = 40.0

        
        /*
         Abhängig davon, welche Taste gedrückt worden ist,
         können wir einen beliebigen Code ausführen. Im
         Folgenden fragen wir die Pfeiltasten ab:
         */
        switch event.keyCode {
        case 123:
            // Pfeiltaste nach LINKS wurde gedrückt
            self.bewege(horizontal: -schrittLänge,
                        vertikal: 0)
        case 124:
            // Pfeiltaste nach RECHTS wurde gedrückt
            self.bewege(horizontal: schrittLänge,
                        vertikal: 0)
        case 125:
            // Pfeiltaste nach UNTEN wurde gedrückt
            self.bewege(horizontal: 0,
                        vertikal: -schrittLänge)
        case 126:
            // Pfeiltaste nach OBEN wurde gedrückt
            self.bewege(horizontal: 0,
                        vertikal: schrittLänge)
        default:
            break
        }
        
    }
    
    
    
    func bewege(horizontal: CGFloat, vertikal: CGFloat) {
    
        /*
         Mit dem 'NSAnimationContext' haben wir die
         Möglichkeit Animationen zu erstellen.
         */
        NSAnimationContext.runAnimationGroup({ _ in
            
            // Berechnung der neuen Position
            let newPosition = NSPoint(x: self.frame.origin.x + horizontal,
                                      y: self.frame.origin.y + vertikal)
            
            // Dauer der Bewegung
            NSAnimationContext.current.duration = 0.3
            
            // Setzen & Animieren der neuen Position
            self.animator().setFrameOrigin(newPosition)
            
        })
        
        /*
         Die folgende Funktion verhindert, dass der Geist
         aus dem Fensterrahmen heraus laufen kann.
         */
        prüfeGrenzüberschreitung()
        
    }
    

    
    func prüfeGrenzüberschreitung() {
        
        let fensterRahmen = self.superview!.frame
        
        // Zu weit links
        if self.frame.origin.x < 0 {
            let maxPositionLinks = NSPoint(x: 0,
                                           y: self.frame.origin.y)
            self.setFrameOrigin(maxPositionLinks)
        }
        
        // Zu weit rechts
        if (self.frame.origin.x + self.frame.width) > fensterRahmen.width {
            let maxPositionRechts = NSPoint(x: fensterRahmen.width - self.frame.width,
                                            y: self.frame.origin.y)
            self.setFrameOrigin(maxPositionRechts)
        }
        
        // Zu weit unten
        if self.frame.origin.y < 0 {
            let maxPositionUnten = NSPoint(x: self.frame.origin.x,
                                           y: 0)
            self.setFrameOrigin(maxPositionUnten)
        }
        
        // Zu weit oben
        if (self.frame.origin.y + self.frame.height) > fensterRahmen.height {
            let maxPositionOben = NSPoint(x: self.frame.origin.x,
                                          y: fensterRahmen.height - self.frame.height)
            self.setFrameOrigin(maxPositionOben)
        }
        
    }
    
    
    
}



