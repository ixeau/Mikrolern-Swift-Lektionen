

import UIKit


class ViewController: UIViewController {

    
    // Outlet
    @IBOutlet weak var meinLabel: UILabel!
    
    
    // Action
    @IBAction func meinButtonAction(_ sender: Any) {
        print("Button gedrückt!")
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Hintergrundfarbe
        view.backgroundColor = UIColor.darkGray
        
        // Label
        meinLabel.text = "Hallo Welt!"
        meinLabel.textColor = UIColor.white
        
    }
    

}

