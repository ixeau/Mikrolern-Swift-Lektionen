/*:
 
 Mikrolern Swift
 # SpriteKit
 **Performante, stromsparende 2D-Spiele**
 */
import PlaygroundSupport
import SpriteKit


// Szene erstellen
let rahmen = CGRect(x: 0, y: 0, width: 300, height: 600)
var szene = SKScene(size: rahmen.size)
szene.backgroundColor = SKColor(red: 0.0,
                                green: 0.13,
                                blue: 0.2,
                                alpha: 1.0)

let mittelpunkt = CGPoint(x: rahmen.size.width / 2.0,
                          y: rahmen.size.height / 2.0)


/*
 Weltraum & Sterne:
 Der Emitter generiert & animiert beliebige Partikel
 */
let emitter = SKEmitterNode()

emitter.particleSize = CGSize(width: 3, height: 3) // Partikel-Größe
emitter.particleColor = SKColor(red: 0.8, green: 0.9, blue: 1.0, alpha: 1.0) // Partikel-Farbe

emitter.particleBirthRate = 128 // Anzahl der Partikel pro Sekunde
emitter.particlePositionRange = CGVector(dx: 0.0, dy: rahmen.size.height)
emitter.position = CGPoint(x: rahmen.size.width, y: mittelpunkt.y)

emitter.particleLifetime = 8 // Lebenszeit in Sekunden
emitter.particleSpeed = 128 // Geschwindigkeit
emitter.particleSpeedRange = 128

emitter.emissionAngle = CGFloat.pi // Angabe in Radiant / Pi = 3.14 = halbe Drehung nach Links
emitter.emissionAngleRange = 0.075

emitter.particleRotation = 0.5 // Drehung um eigene Achse
emitter.particleRotationSpeed = 0.75
emitter.particleRotationRange = 0.5

emitter.particleAlpha = 0.5 // Transparenz
emitter.particleAlphaRange = 0.4

emitter.advanceSimulationTime(4) // Vor-Berechnung der Partikel beim Start


/*
 Regenbogenkatze:
 Mit dem 'SKSpriteNode' platzieren wir ein Objekt in der Szene
 */
let objekt = SKSpriteNode(imageNamed: "Regenbogenkatze")
objekt.position = mittelpunkt
objekt.setScale(0.8)
objekt.zPosition = 10

objekt.run(
    // Animation: Wackeln
    SKAction.repeatForever(
        SKAction.sequence([
            SKAction.rotate(toAngle: 0.05, duration: 0.2),
            SKAction.rotate(toAngle: -0.01, duration: 0.2),
            ])
    )
)

objekt.run(
    // Animation: Hoch- & runter Bewegung
    SKAction.repeatForever(
        SKAction.sequence([
            SKAction.moveBy(x: 10, y: 40, duration: 2.0),
            SKAction.moveBy(x: -10, y: -40, duration: 2.0)
            ])
    )
)


// Szene zusammenfügen
szene.addChild(emitter)
szene.addChild(objekt)


// Szene im Playground anzeigen
let vorschau = SKView(frame: rahmen)
vorschau.presentScene(szene)
PlaygroundPage.current.liveView = vorschau


// Zur Dokumentation von Apple geht’s hier entlang:
// https://developer.apple.com/spritekit/
/*:
 © 2018 IXEAU UG (haftungsbeschränkt). Alle Rechte vorbehalten.
 */
