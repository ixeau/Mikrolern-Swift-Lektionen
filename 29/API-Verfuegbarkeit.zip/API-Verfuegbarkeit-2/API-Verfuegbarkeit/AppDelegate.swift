


import Cocoa



@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {


    let statusBar = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        
        statusBar.title = "🤖"
        
        // Menu
        let menu = NSMenu()
        menu.autoenablesItems = false
        
        // Menu Item
        let menuItem = NSMenuItem()
        menuItem.title = "Hallo Welt"
        menuItem.keyEquivalent = "W"

        // menuItem.allowsKeyEquivalentWhenHidden = true
        
        if #available(macOS 10.13, *) {
            menuItem.allowsKeyEquivalentWhenHidden = true
            /*
             Das Attribut '.allowsKeyEquivalentWhenHidden' bewirkt, dass der Shortcut
             auch funktioniert, wenn die App nicht im Vodergrund (aktiviert) ist.
             Sie ist jedoch erst ab macOS 10.13 verfügbar. Daher nutzen wir an dieser
             Stelle 'if #available', damit Nutzer von macOS 10.13 oder neuer in den Genuss
             dieser Funktion kommen, während alle anderen zumindest den Rest nutzen können :)
             */
        }
        
        // Fertigstellung
        menu.addItem(menuItem)
        statusBar.menu = menu
        
    }



}



