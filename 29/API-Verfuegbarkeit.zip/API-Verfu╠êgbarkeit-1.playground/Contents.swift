/*:
 
 Mikrolern Swift
 # API-Verfügbarkeit
 **Code ausführen in Abhängigkeit vom genutzten System**
 */
import Cocoa


if #available(iOS 11, macOS 10.13, *) {
    
    /*
     Code in diesem Block wird ausgeführt auf:
     - Geräten mit iOS ab Version 11
     - Geräten mit macOS ab Version 10.13
     - Der Stern am Ende steht stellvertretend für zukünftige OS-Versionen
     
     Plattformen, deren Verfügbarkeit man i.d.R. prüft:
     iOS, macOS, watchOS, tvOS
     */
    
} else {
    
    /*
     Dieser Code-Block wird ausgeführt, wenn die
     gewünschte Plattform / API nicht verfügbar ist.
     */
    
}


// Funktion, die erst ab tvOS 4 verfügbar ist:
@available(tvOS 4, *)
func helloWorld() {
    // Dieser Code wird nur ab tvOS 4 oder höher ausgeführt.
}


// Struktur, die erst ab iOS 9 verfügbar ist:
@available(iOS 9, *)
struct Person {
    // Dieser Code wird nur ab iOS 9 oder höher ausgeführt.
    var name = ""
    var nachname = ""
}


// Funktion, die mithilfe von 'guard' innerhalb der Funktion die angegebene Version prüft.
func istHighSierraVerfügbar() -> Bool {
    guard #available(macOS 10.13, *) else {
        print("Gewünschte macOS-Version nicht verfügbar.")
        return false
    }
    print("macOS High Sierra oder höher verfübar.")
    return true
}

istHighSierraVerfügbar()
/*:
 © 2018 IXEAU UG (haftungsbeschränkt). Alle Rechte vorbehalten.
 */
