//
//  AppDelegate.swift
//  StatusBarDemo
//
//  Created by Martin Lexow on 07.12.17.
//  Copyright © 2017 IXEAU. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    
    // StatusBar
    let statusBar = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        
        statusBar.title = "🤓"
        
        // Maus-Events überwachen
        NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved]) {
            _ in
            self.determineStatusBarTitle()
        }
        
        NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved]) {
            self.determineStatusBarTitle()
            return $0
        }
        
    }

    
    func determineStatusBarTitle() {
        
        // Bildschirmauflösung
        let screenResolution = NSScreen.main!.frame.size
        print("Bildschirm: \(screenResolution)")
        
        // Mausposition
        let mouseLocation = NSEvent.mouseLocation
        print("Maus X:\t\t\(mouseLocation.x)") // horizontal
        print("Maus Y:\t\t\(mouseLocation.y)") // vertikal
        
        // Mauslevel (in Prozent)
        let mouseLevel = mouseLocation.y / screenResolution.height * 100
        print("Maushöhe:\t\(ceil(mouseLevel)) %\n")
        
        // Zustände
        if mouseLevel <= 100.0 {
            statusBar.title = "☀️"
        }
        
        if mouseLevel <= 80.0 {
            statusBar.title = "🌤"
        }
        
        if mouseLevel <= 60.0 {
            statusBar.title = "🌥"
        }
        
        if mouseLevel <= 40.0 {
            statusBar.title = "☁️"
        }
        
        if mouseLevel <= 20.0 {
            statusBar.title = "🌧"
        }
        
    }
    


}

